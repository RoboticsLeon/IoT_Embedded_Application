BASIC EXAMPLE FOR LAUNCHPAD 
(base on examples/platform-specific/cc26x0-cc13x0/base-demo/base-demo.c)
